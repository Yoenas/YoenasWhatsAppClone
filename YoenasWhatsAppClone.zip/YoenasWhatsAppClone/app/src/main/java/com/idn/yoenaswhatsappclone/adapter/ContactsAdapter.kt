package com.idn.yoenaswhatsappclone.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.idn.yoenaswhatsappclone.R
import com.idn.yoenaswhatsappclone.util.Contact

class ContactsAdapter(val contacts: ArrayList<Contact>) :
    RecyclerView.Adapter<ContactsAdapter.ContactsViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ContactsViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_contact, parent, false))

    override fun getItemCount() = contacts.size

    override fun onBindViewHolder(holder: ContactsViewHolder, position: Int) {
        TODO("Not yet implemented")
    }

    class ContactsViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        fun bindItem(contact: Contact) {

        }
    }

}
